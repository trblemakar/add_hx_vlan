__author__ = 'jamakar'

import argparse

def get_args():
    # get command line args

    parser = argparse.ArgumentParser(description='Arguments for Add HX VLAN')

    parser.add_argument('-r', '--config_file',
                        action='store',
                        help='Remove VLANs/portgroups from UCSM/vCenter using json file input')

    args = parser.parse_args()

    return args
