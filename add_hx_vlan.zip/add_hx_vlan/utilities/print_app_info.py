__author__ = 'jamakar'

def print_app_info(app_version):
    # print version info

    print("*** {}, Still in development, for lab or test environments only! ***" .format(app_version))
    print("Add new VM Network VLAN(s) to HyperFlex System")
    print("Requires UCSM version 3.2 or 4.0")
    print("Requires HyperFlex version 3.5")
    print("Requires vSphere version 6.0+")
