__author__ = 'jamakar'

def print_info(app_version):
    # print version info
    print("*** Still in development, for lab or test environments only! ***")
    print("Add new VM Network VLAN(s) to HyperFlex System {}".format(app_version))
    print("Requires UCSM version 3.2 or 4.0")
    print("Requires HyperFlex version 3.5")
    print("Requires vSphere version 6.0+")
