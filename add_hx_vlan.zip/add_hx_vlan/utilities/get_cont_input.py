__author__ = 'jamakar'

def is_yes_no(input):
    # check for yes or no answer
    return input.lower() == "yes" or input.lower() == "no"


def get_cont_input():
    # checks for yes or no
    while True:
        try:
            input = raw_input("Would you like to continue? [Yes/No]: ")
            assert is_yes_no(input)
            return input
        except AssertionError:
            print("*** Invalid Response. Please try again! ***")
            print("Continue: Yes or No")
