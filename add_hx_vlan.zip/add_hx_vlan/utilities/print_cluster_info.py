__author__ = 'jamakar'

def print_cluster_info(config, with_vlan=False):

    # print discovered UCSM info
    print("Discovered UCSM Domain: {} and Org: {}".format(config['ucsm_vip'],
                                                          config['ucsm_org']))

    # print discovered vCenter info
    print("Discovered vCenter: {}, Datacenter: {} and Cluster: {}".format(config['vcenter_ip'],
                                                                          config['vcenter_datacenter_name'],
                                                                          config['vcenter_cluster_name']))

    if with_vlan:
        for vlan in config['vlans']:
            print("REMOVE VLAN/Portgroup: {}, ID: {}".format(vlan['name'],
                                                             vlan['vlan_id']))
