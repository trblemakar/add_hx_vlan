__author__ = 'jamakar'

import json

def load_json_file(file_name):
    # load json file, return dict

    try:
        # Load json file
        file_data = open(file_name)
        config = {}
        config = json.load(file_data)
        print("Read and loaded config file: {}" .format(file_name))
        return config
    except IOError:
        print("*** json file Error ***")
        print("*** Cannot open: {}" .format(file_name))
        exit()
