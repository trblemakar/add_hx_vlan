__author__ = 'jamakar'

def validate_ip(ip_address):
    # checks IP address for invalid characters
    # doesn't work with FQDN

    if ip_address.split("."):
        ip_list = ip_address.split(".")
        if len(ip_list) == 4:
            for ip in ip_list:
                if int(ip) <= 0 or int(ip) > 255:
                    return False
        else:
            return False
    else:
        return False
    return True


def get_ip_address_input(text):
    # checks IP address format
    while True:
        try:
            ip_address = raw_input(text)
            assert validate_ip(ip_address)
            return ip_address
        except AssertionError:
            print("*** Invalid IP address. Please try again! ***")
