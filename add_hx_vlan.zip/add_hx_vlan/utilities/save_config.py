__author__ = 'jamakar'

import json
from datetime import datetime

def save_config(config):
    # save config to json file

    # current date and time
    now = datetime.now()

    # format timestamp
    timestamp = str(now).replace(" ", "_")

    with open(config['vcenter_cluster_name'] + '_' + timestamp + '.json', 'w') as fp:
        json.dump(config, fp, indent=4)
