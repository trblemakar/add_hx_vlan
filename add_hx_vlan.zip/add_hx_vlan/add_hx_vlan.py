from __future__ import print_function
from utilities.getpassword import getpassword
from utilities.get_cont_input import get_cont_input
from UCS.ucsm_version_check import ucsm_version_check
from HyperFlex.get_hx_auth_token import get_hx_auth_token
from HyperFlex.get_hx_clusters import get_hx_clusters
from UCS.get_vlan_name_input import get_vlan_name_input
from UCS.get_vlan_id_input import get_vlan_id_input
from UCS.create_ucs_vlan import create_ucs_vlan
from UCS.add_vlan_to_vnic_temp import add_vlan_to_vnic_temp
from UCS.get_sp_vnic_mac import get_sp_vnic_mac
from ucsmsdk.ucshandle import UcsHandle
from pyVim.connect import SmartConnectNoSSL, Disconnect
from vmware.get_cluster_hosts import get_cluster_hosts
from vmware.get_vm_network_name import get_vm_network_name
from vmware.add_portgroup import add_portgroup
import atexit

__author__ = 'jamakar'

# Adds new VLAN to UCSM and vCenter Cluster for HyperFlex

# Requires the UCS Python SDK v0.9.8 and VMware pyvmomi
# tested on UCSM version 4.0; HyperFlex version 3.5; vSphere 6.7

# Version 0.9.2

# Usage: python add_hx_vlan.py

if __name__ == "__main__":

    # print version info
    print("*** Still in development, for lab or test environments only! ***")
    print("Add new VM Network VLAN to HyperFlex System v0.9.2")
    print("Requires UCSM version 3.2 or 4.0")
    print("Requires HyperFlex version 3.5")
    print("Requires vSphere version 6.0+")

    try:
        hx_connect_ip = raw_input("Enter HX Connect IP: ")
        hx_connect_password = getpassword("Enter HX Connect Password: ")
    except IOError:
        print("*** User Input Error ***")
        exit()

    try:
        # set HX Connect username, not needed if embedded within HX Connect
        hx_connect_username = "admin"

        # get HX Connect auth token
        hx_auth_token = get_hx_auth_token(hx_connect_ip, hx_connect_username, hx_connect_password)

        # get HX cluster info from HX Connect
        hx_url_clusters = 'https://%s/rest/clusters' % hx_connect_ip
        hx_clusters_list = get_hx_clusters(hx_auth_token, hx_url_clusters)
        hx_clusters_dict = hx_clusters_list[0]

        # get UCSM info from HX Connect
        ucsm_org = hx_clusters_dict[u'config'][u'ucsmOrg']
        ucsm_vip = hx_clusters_dict[u'config'][u'ucsmHostName']

        # get vCenter info from HX Connect
        vcenter_datacenter_name = hx_clusters_dict[u'config'][u'vCenterDatacenter']
        vcenter_cluster_name = hx_clusters_dict[u'config'][u'vCenterClusterName']
        vcenter_ip = hx_clusters_dict[u'config'][u'vCenterURL']

        print("Discovered UCSM Domain: {} and Org: {}".format(ucsm_vip, ucsm_org))
        print("Discovered vCenter: {}, Datacenter: {} and Cluster: {}".format(vcenter_ip,
                                                                              vcenter_datacenter_name,
                                                                              vcenter_cluster_name))
    except IOError:
        print("*** HX Connect Login Error ***")
        exit()

    try:
        cont = get_cont_input()
        if cont.lower() == "yes":
            vlan_name = get_vlan_name_input()
            vlan_id = get_vlan_id_input()
            ucsm_password = getpassword("Enter UCSM Password: ")
            vcenter_username = raw_input("Enter vCenter Username: ")
            vcenter_password = getpassword("Enter vCenter Password: ")
        else:
            exit()
    except IOError:
        print("*** User Input Error ***")
        exit()

    try:
        # set UCSM username to admin, should be user input within HX Connect
        ucsm_username = "admin"

        # set vCenter username, should be user input within HX Connect
        #vcenter_username = "administrator@cisco.com"

        # set vnic name
        vnic_name = "vm-network-a"

        # Create default VLAN 'shell' for new VLAN within UCSM
        new_vlan = {
            "name": vlan_name,
            "sharing": "none",
            "vlan_id": str(vlan_id),
            "mcast_policy_name": "",
            "policy_owner": "local",
            "compression_type": "included",
            "default_net": "no",
            "pub_nw_name": "",
            "vlan_dn": "fabric/lan"
        }

        # set UCSM parent dn
        parent_dn = "org-root/org-" + ucsm_org

        try:
            # Open UCSM session
            ucsm_handle = UcsHandle(ucsm_vip, ucsm_username, ucsm_password)
            ucsm_handle.login()
        except IOError:
            print("*** UCS Login Error ***")
            exit()

        # Do UCSM version check 3.2 or above
        ucsm_version_check(ucsm_handle)

        # Create new VLAN within UCSM
        create_ucs_vlan(ucsm_handle, new_vlan)

        # Add new VLAN to vm-network-a vNIC template within UCSM, only primary vNIC required
        add_vlan_to_vnic_temp(ucsm_handle, parent_dn, new_vlan, vnic_name)

        # get mac address from UCSM assigned to vm-network-a vNIC
        ucs_mac = get_sp_vnic_mac(ucsm_handle, parent_dn, vnic_name)

        # Close UCSM session
        ucsm_handle.logout()

        try:
            # Login to vCenter, skips SSL verification
            serviceInstance = SmartConnectNoSSL(host=vcenter_ip,
                                                user=vcenter_username,
                                                pwd=vcenter_password,
                                                port=443)
            atexit.register(Disconnect, serviceInstance)
            content = serviceInstance.RetrieveContent()
        except IOError:
            print("*** vCenter Login Error ***")
            exit()

        # get host list for the HX cluster we want to add the new VLAN to
        hosts = get_cluster_hosts(content, vcenter_datacenter_name, vcenter_cluster_name)

        # get network type (vswitch/DVS) and vm network name from vCenter
        vm_network = get_vm_network_name(hosts, ucs_mac)

        # add portgroup to vswitch or DVS
        # this assume the first valid entry is correct for all vswitch/DVS names
        add_portgroup(content, hosts, vm_network, vlan_name, vlan_id)

    except IOError:
        print("*** Config Error ***")
        exit()

else:
    exit()
