__author__ = 'jamakar'

from utilities.print_info import print_info
from HyperFlex.get_hx_connect_info import get_hx_connect_info
from utilities.getpassword import getpassword
from utilities.get_cont_input import get_cont_input
from utilities.save_config import save_config
from UCS.get_vlan_name_input import get_vlan_name_input
from UCS.get_vlan_id_input import get_vlan_ids_input
from UCS.config_ucs_vlans import config_ucs_vlans
from vmware.config_vcenter_portgroups import config_vcenter_portgroups

# Version 0.9.9
# Adds new VLAN or range of VLANs to UCSM and vCenter Cluster for HyperFlex
# Requires the UCS Python SDK v0.9.8 and VMware pyvmomi
# tested on UCSM version 4.0; HyperFlex version 3.5; vSphere 6.7
# Usage: python add_hx_vlan.py

if __name__ == "__main__":

    # print app info
    print_info("v0.9.9")

    # dict to save config
    config = {}

    # get HX, UCSM, vCenter cluster info from HX Connect
    config = get_hx_connect_info()

    # ask user if they would like to continue
    cont = get_cont_input()
    if cont.lower() == "yes":
        # get VLAN info
        config['vlan_name'] = get_vlan_name_input()
        config['vlan_ids'] = get_vlan_ids_input()

        # set UCSM username to admin, should be user input within HX Connect
        # get USCM password, should be user input within HX Connect
        config['ucsm_username'] = "admin"
        ucsm_password = getpassword("Enter UCSM Password: ")

        # get/set vCenter username, should be user input within HX Connect
        # get vCenter password, should be user input within HX Connect
        config['vcenter_username'] = raw_input("Enter vCenter Username: ")
        #config['vcenter_username'] = "administrator@cisco.com"
        vcenter_password = getpassword("Enter vCenter Password: ")

        # set vnic name, statically defined during HX install, a&b adapters are peers
        config['vnic_name'] = "vm-network-a"

        # create new UCS VLANs, add them to vNIC temp, return updated config dict
        config.update(config_ucs_vlans(config, ucsm_password))

        # create new portgroups in vCenter, return updated config dict
        config.update(config_vcenter_portgroups(config, vcenter_password))

        # save config to json file
        save_config(config)
    else:
        exit()
else:
    exit()
