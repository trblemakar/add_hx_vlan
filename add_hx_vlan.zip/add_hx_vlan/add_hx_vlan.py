__author__ = 'jamakar'

from utilities.get_args import get_args
from utilities.load_json_file import load_json_file
from utilities.print_app_info import print_app_info
from HyperFlex.get_hx_connect_info import get_hx_connect_info
from utilities.print_cluster_info import print_cluster_info
from utilities.get_cont_input import get_cont_input
from utilities.getpassword import getpassword
from utilities.save_config import save_config
from UCS.get_vlan_name_input import get_vlan_name_input
from UCS.get_vlan_id_input import get_vlan_ids_input
from UCS.config_ucs_vlans import config_ucs_vlans
from UCS.remove_ucs_vlans import remove_ucs_vlans
from vmware.login_vcenter import login_vcenter
from vmware.config_vcenter_portgroups import config_vcenter_portgroups
from vmware.remove_portgroup import remove_portgroup

# Version 1.0.12
# Adds new VLAN or range of VLANs to UCSM and vCenter Cluster for HyperFlex
# Requires the UCS Python SDK v0.9.8 and VMware pyvmomi
# tested on UCSM version 4.0; HyperFlex version 3.5; vSphere 6.7
# Usage: python3 add_hx_vlan.py

if __name__ == "__main__":

    # get command line args
    args = get_args()

    # if -r added at run time with config file, remove config via json file
    if args.config_file:
        # load config file to remove VLAN(s)/Portgroup(s)
        config = load_json_file(args.config_file)

        # print discovered cluster info
        print_cluster_info(config, with_vlan=True)

        # ask user if they would like to continue
        cont = get_cont_input()
        if cont.lower() == "yes":
            # get UCSM password
            ucsm_password = getpassword("Enter UCSM Password: ")

            # get vCenter password
            vc_password = getpassword("Enter vCenter Password: ")

            # remove UCS VLAN(s) from system and vNIC template
            remove_ucs_vlans(config, ucsm_password)

            # login to vCenter
            content = login_vcenter(config, vc_password)

            # remove portgroup(s)
            remove_portgroup(content, config)

        else:
            # if no to delete, exit
            exit()

    # if no command line arg -r, run normal add VLAN script
    else:
        # print app info
        print_app_info("v1.0.12")

        # dict to save config
        config = {}

        # get HX, UCSM, vCenter cluster info from HX Connect
        config = get_hx_connect_info()

        # print discovered cluster info
        print_cluster_info(config)

        # ask user if they would like to continue
        cont = get_cont_input()
        if cont.lower() == "yes":
            # get VLAN info from user
            config['vlan_name'] = get_vlan_name_input()
            config['vlan_ids'] = get_vlan_ids_input()

            # set vnic name, statically defined during HX install, a&b adapters are peers
            config['vnic_name'] = "vm-network-a"

            # set UCSM username to admin, should be user input within HX Connect
            config['ucsm_username'] = "admin"
            # get UCSM password
            ucsm_password = getpassword("Enter UCSM Password: ")

            # get/set vCenter username, should be user input within HX Connect
            #config['vcenter_username'] = "administrator@cisco.com"
            config['vcenter_username'] = input("Enter vCenter Username: ")
            # get vCenter password, should be user input within HX Connect
            vc_password = getpassword("Enter vCenter Password: ")

            # create new UCS VLAN(s), add them to vNIC temp, return updated config dict
            config.update(config_ucs_vlans(config, ucsm_password))

            # create new portgroup(s) in vCenter, return updated config dict
            config.update(config_vcenter_portgroups(config, vc_password))

            # save config to json file
            save_config(config)

        else:
            # if user does not want to add new VLAN(s), exit
            exit()

else:
    # exit main
    exit()
