from __future__ import print_function
from utilities.getpassword import getpassword
from UCS.ucsm_version_check import ucsm_version_check
from HyperFlex.get_hx_auth_token import get_hx_auth_token
from HyperFlex.get_hx_clusters import get_hx_clusters
from UCS.get_vlan_name_input import get_vlan_name_input
from UCS.get_vlan_id_input import get_vlan_id_input
from UCS.create_ucs_vlan import create_ucs_vlan
from UCS.add_vlan_to_vnic_temp import add_vlan_to_vnic_temp
from UCS.get_sp_vnic_macs import get_sp_vnic_macs
from ucsmsdk.ucshandle import UcsHandle
from pyVim.connect import SmartConnectNoSSL, Disconnect
from vmware.get_cluster_hosts import get_cluster_hosts
from vmware.get_mac_to_vswitch_names import get_mac_to_vswitch_names
from vmware.add_pg_vswitch import add_hosts_portgroup
import atexit

__author__ = 'jamakar'

# Adds new VLAN to UCSM and vCenter Cluster for HyperFlex

# Requires the UCS Python SDK v0.9.8 and VMware pyvmomi
# UCSM version 3.2, 4.0; HyperFlex version 3.5; vSphere 6.7

# Version 0.8.2

# Usage: python add_hx_vlan.py

if __name__ == "__main__":

    # print version info
    print("*** Still in development, for lab or test environments only! ***")
    print("Add new VLAN to HyperFlex System v0.8.2")
    print("Requires UCSM version 3.2 or 4.0")
    print("Requires HyperFlex version 3.5")
    print("Requires vSphere version 6.0+, uses vswitch")

    try:
        vlan_name = get_vlan_name_input()
        vlan_id = get_vlan_id_input()
        hx_connect_ip = raw_input("Enter HX Connect IP: ")
        hx_connect_password = getpassword("Enter HX Connect Password: ")
        ucsm_password = getpassword("Enter UCSM Password: ")
        vcenter_username = raw_input("Enter vCenter Username: ")
        vcenter_password = getpassword("Enter vCenter Password: ")

    except IOError:
        print("*** User Input Error ***")
        exit()

    try:

        # set HX Connect username, not needed if embedded within HX Connect
        hx_connect_username = "admin"

        # set UCSM username to admin, should be user input within HX Connect
        ucsm_username = "admin"

        # set vCenter username, should be user input within HX Connect
        #vcenter_username = "administrator@cisco.com"

        # set vnic name
        vnic_name = "vm-network-a"

        # Create default VLAN 'shell' for new VLAN within UCSM
        new_vlan = {
            "name": vlan_name,
            "sharing": "none",
            "vlan_id": str(vlan_id),
            "mcast_policy_name": "",
            "policy_owner": "local",
            "compression_type": "included",
            "default_net": "no",
            "pub_nw_name": "",
            "vlan_dn": "fabric/lan"
        }

        # get HX Connect auth token
        hx_auth_token = get_hx_auth_token(hx_connect_ip, hx_connect_username, hx_connect_password)

        # get HX cluster info from HX Connect
        hx_url_clusters = 'https://%s/rest/clusters'%hx_connect_ip
        hx_clusters_list = get_hx_clusters(hx_auth_token, hx_url_clusters)
        hx_clusters_dict = hx_clusters_list[0]

        # get UCSM info from HX Connect
        ucsm_org = hx_clusters_dict[u'config'][u'ucsmOrg']
        ucsm_vip = hx_clusters_dict[u'config'][u'ucsmHostName']

        # set UCSM parent dn
        parent_dn = "org-root/org-" + ucsm_org

        # get vCenter info from HX Connect
        vcenter_datacenter_name = hx_clusters_dict[u'config'][u'vCenterDatacenter']
        vcenter_cluster_name = hx_clusters_dict[u'config'][u'vCenterClusterName']
        vcenter_ip = hx_clusters_dict[u'config'][u'vCenterURL']

        try:
            # Open UCSM session
            ucsm_handle = UcsHandle(ucsm_vip, ucsm_username, ucsm_password)
            ucsm_handle.login()

        except IOError:
            print("*** UCS Login Error ***")
            exit()

        # Do UCSM version check 3.2 or above
        ucsm_version_check(ucsm_handle)

        # Create new VLAN within UCSM
        create_ucs_vlan(ucsm_handle, new_vlan)

        # Add new VLAN to vm-network-a vNIC template within UCSM, only primary vNIC required
        add_vlan_to_vnic_temp(ucsm_handle, parent_dn, new_vlan, vnic_name)

        # get mac addresses from UCSM assigned to vm-network-a vNICs
        ucs_macs = get_sp_vnic_macs(ucsm_handle, parent_dn, vnic_name)

        # Close UCSM session
        ucsm_handle.logout()

        # Login to vCenter, skips SSL verification
        serviceInstance = SmartConnectNoSSL(host=vcenter_ip,
                                            user=vcenter_username,
                                            pwd=vcenter_password,
                                            port=443)

        atexit.register(Disconnect, serviceInstance)
        content = serviceInstance.RetrieveContent()

        # get host list for the HX cluster we want to add the new VLAN to
        hosts = get_cluster_hosts(content, vcenter_datacenter_name, vcenter_cluster_name)

        # get mapping of vswitch names to physical vmnic mac addresses from vCenter
        vswitch_names = get_mac_to_vswitch_names(hosts)

        # add VLAN/portgroup to each host in the cluster
        # this checks each MAC of each host which is slow, you could assume the first valid entry is correct for all
        add_hosts_portgroup(hosts, ucs_macs, vswitch_names, vlan_name, vlan_id)

    except IOError:
        print("*** Config Error ***")
        exit()

else:
    exit()
