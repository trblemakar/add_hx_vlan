__author__ = 'jamakar'

from utilities.getpassword import getpassword
from HyperFlex.get_hx_auth_token import get_hx_auth_token
from HyperFlex.get_hx_clusters import get_hx_clusters

def get_hx_connect_info():
    # logs into HX Connect and collects cluster info into a dict, returns dict
    hx_config = {}

    hx_config['hx_connect_ip'] = input("Enter HX Connect IP: ")
    hx_connect_password = getpassword("Enter HX Connect Password: ")

    # set HX Connect username, not needed if embedded within HX Connect
    hx_config['hx_connect_username'] = "admin"

    # get HX Connect auth token
    hx_auth_token = get_hx_auth_token(hx_config['hx_connect_ip'],
                                      hx_config['hx_connect_username'],
                                      hx_connect_password)

    # get HX cluster info from HX Connect
    hx_url_clusters = 'https://%s/rest/clusters' % hx_config['hx_connect_ip']
    hx_clusters_list = get_hx_clusters(hx_auth_token, hx_url_clusters)
    hx_clusters_dict = hx_clusters_list[0]

    # get UCSM info from HX Connect
    hx_config['ucsm_org'] = hx_clusters_dict[u'config'][u'ucsmOrg']
    hx_config['ucsm_vip'] = hx_clusters_dict[u'config'][u'ucsmHostName']

    # get vCenter info from HX Connect
    hx_config['vcenter_datacenter_name'] = hx_clusters_dict[u'config'][u'vCenterDatacenter']
    hx_config['vcenter_cluster_name'] = hx_clusters_dict[u'config'][u'vCenterClusterName']
    hx_config['vcenter_ip'] = hx_clusters_dict[u'config'][u'vCenterURL']

    return hx_config
