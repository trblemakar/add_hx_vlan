__author__ = 'jamakar'

def get_hx_auth_token(host, username, password):

    import requests
    import json

    # suppress the unverified request messages (when using self-signed certificates)
    requests.packages.urllib3.disable_warnings()

    url = 'https://%s/aaa/v1/auth?grant_type=password'%host
    headers={'content-type':'application/json'}

    payload = {
            "username": username,
            "password": password,
            "client_id": "HxGuiClient",
            "client_secret": "Sunnyvale",
            "redirect_uri": "http://"+host
    }

    try:
        response = requests.post(url,headers=headers,data=json.dumps(payload),verify=False,timeout=4)
        if response.status_code == 201:
                if response.json().get('access_token'):
                        return response.json()
        print("Failed to get a HX Connect token")
        print response.content
        return None
    except Exception as e:
        print("Post for token failed: {}".format(str(e)))
        return None
