__author__ = 'jamakar'

def get_hx_clusters(authdata, url):

    import requests

    try:
        headers = {'Authorization': authdata['token_type'] + ' ' + authdata['access_token'],'Connection':'close'}
        response = requests.get(url,headers=headers,verify=False,timeout=4)
        if response.status_code == 200:
            return response.json()
        return None
    except Exception as e:
        print("Post for HX Connect data failed \n"+str(e))
        return None
