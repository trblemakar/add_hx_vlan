__author__ = 'jamakar'

def get_cluster_hosts(content, datacenter_name, cluster_name):
    # returns hosts list for a given datacenter and cluster name

    children = content.rootFolder.childEntity
    for child in children:  # Iterate though DataCenters
        dc = child
        if dc.name == datacenter_name:
            clusters = dc.hostFolder.childEntity
            for cluster in clusters:  # Iterate through the clusters in the DC
                if cluster.name == cluster_name:
                    hosts = cluster.host  # Variable to make pep8 compliance
                    return hosts
