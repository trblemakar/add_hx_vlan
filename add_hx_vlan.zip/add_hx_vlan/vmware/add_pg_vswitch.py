from __future__ import print_function
from pyVmomi import vim

__author__ = 'jamakar'

def add_hosts_portgroup(hosts, ucs_macs, vswitch_names, portgroup_name, vlan_id):

    for host in hosts:
        for mac in ucs_macs:
            if mac in vswitch_names[host.name].keys():
                add_host_portgroup(host, vswitch_names[host.name][mac], portgroup_name, vlan_id)
                print("Added portgroup: {}({}) to vswitch: {} on host: {}".format(portgroup_name,
                                                                                  vlan_id,
                                                                                  vswitch_names[host.name][mac],
                                                                                  host.name))


def add_host_portgroup(host, vswitch_name, portgroup_name, vlan_id):

    portgroup_spec = vim.host.PortGroup.Specification()
    portgroup_spec.vswitchName = vswitch_name
    portgroup_spec.name = portgroup_name
    portgroup_spec.vlanId = int(vlan_id)
    network_policy = vim.host.NetworkPolicy()
    network_policy.security = vim.host.NetworkPolicy.SecurityPolicy()
    network_policy.security.allowPromiscuous = True
    network_policy.security.macChanges = False
    network_policy.security.forgedTransmits = False
    portgroup_spec.policy = network_policy

    host.configManager.networkSystem.AddPortGroup(portgroup_spec)