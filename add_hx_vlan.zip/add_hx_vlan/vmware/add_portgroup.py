__author__ = 'jamakar'

def add_portgroup(content, hosts, vm_network, portgroup_name, vlan_id):
    # adds new portgroup to vswitch or DVS

    from pyVmomi import vim
    from vmware.add_dvs_portgroup import add_dvs_portgroup
    from vmware.add_vswitch_portgroup import add_vswitch_portgroup
    from vmware.get_cluster_obj import get_cluster_obj

    if vm_network['is_dvs']:
        dvs_name = vm_network['network_name']
        dv_switch = get_cluster_obj(content, [vim.DistributedVirtualSwitch], dvs_name)
        add_dvs_portgroup(dv_switch, portgroup_name, vlan_id)
        print("Added portgroup: {}({}) to DVS: {}".format(portgroup_name,
                                                          vlan_id,
                                                          dvs_name))

    else:
        vswitch_name = vm_network['network_name']
        for host in hosts:
            add_vswitch_portgroup(host, vswitch_name, portgroup_name, vlan_id)
            print("Added portgroup: {}({}) to vswitch: {} on host: {}".format(portgroup_name,
                                                                              vlan_id,
                                                                              vswitch_name,
                                                                              host.name))
