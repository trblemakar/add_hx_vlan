__author__ = 'jamakar'

from pyVmomi import vim
from vmware.add_dvs_portgroup import add_dvs_portgroup
from vmware.add_vswitch_portgroup import add_vswitch_portgroup
from vmware.get_cluster_obj import get_cluster_obj

def add_portgroup(content, hosts, vm_network, portgroup_name, vlan_id):
    # adds new portgroup to vswitch or DVS

    if vm_network['is_dvs']:
        dvs_name = vm_network['network_name']
        dv_switch = get_cluster_obj(content, [vim.DistributedVirtualSwitch], dvs_name)
        add_dvs_portgroup(dv_switch, dvs_name, portgroup_name, vlan_id)

    else:
        vswitch_name = vm_network['network_name']
        for host in hosts:
            add_vswitch_portgroup(host, vswitch_name, portgroup_name, vlan_id)
