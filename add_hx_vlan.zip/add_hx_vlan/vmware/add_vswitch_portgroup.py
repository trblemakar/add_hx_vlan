__author__ = 'jamakar'

from pyVmomi import vim

def add_vswitch_portgroup(host, vswitch_name, portgroup_name, vlan_id):
    # add portgroup to vswitch

    portgroup_spec = vim.host.PortGroup.Specification()
    portgroup_spec.vswitchName = vswitch_name
    portgroup_spec.name = portgroup_name
    portgroup_spec.vlanId = int(vlan_id)
    network_policy = vim.host.NetworkPolicy()
    network_policy.security = vim.host.NetworkPolicy.SecurityPolicy()
    network_policy.security.allowPromiscuous = True
    network_policy.security.macChanges = False
    network_policy.security.forgedTransmits = False
    portgroup_spec.policy = network_policy

    host.configManager.networkSystem.AddPortGroup(portgroup_spec)

    print("vCenter: Added portgroup: {}({}) to vswitch: {} on host: {}".format(portgroup_name,
                                                                               vlan_id,
                                                                               vswitch_name,
                                                                               host.name))
