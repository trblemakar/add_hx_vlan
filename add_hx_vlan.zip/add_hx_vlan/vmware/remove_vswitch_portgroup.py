__author__ = 'jamakar'

def remove_vswitch_portgroup(host, portgroup_name):
    # remove portgroup for vswitch

    host.configManager.networkSystem.RemovePortGroup(portgroup_name)

    print("vCenter: Removed portgroup: {} from host: {}" .format(portgroup_name,
                                                                 host.name))
