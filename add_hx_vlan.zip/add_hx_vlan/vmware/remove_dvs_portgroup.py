__author__ = 'jamakar'

from pyVmomi import vim
from vmware.get_cluster_obj import get_cluster_obj

def remove_dvs_portgroup(content, dvs_name, portgroup_name):
    # remove portgroup from DVS

    dv_switch = get_cluster_obj(content, [vim.DistributedVirtualSwitch], dvs_name)

    for portgroup in dv_switch.portgroup:
        if portgroup.name == portgroup_name:
            task = portgroup.Destroy_Task()

    print("vCenter: Removed portgroup: {} from DVS: {}" .format(portgroup_name,
                                                                dvs_name))
