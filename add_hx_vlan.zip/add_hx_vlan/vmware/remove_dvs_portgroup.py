__author__ = 'jamakar'

from pyVmomi import vim

def remove_dvs_portgroup(content, dvs_name, portgroup_name):
    # remove portgroup from DVS

    portgroup = None

    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.DistributedVirtualSwitch], True)

    for dvs in container.view:
        if dvs.name == dvs_name:
            dv_switch = dvs

    portgroups = dv_switch.portgroup

    for pg in portgroups:
        if pg.name == portgroup_name:
            portgroup = pg

    task = portgroup.Destroy_Task()

    print("vCenter: Removed portgroup: {} from DVS: {}" .format(portgroup_name,
                                                                dvs_name))
