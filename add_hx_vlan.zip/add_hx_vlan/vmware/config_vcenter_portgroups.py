__author__ = 'jamakar'

from pyVim.connect import SmartConnectNoSSL, Disconnect
from vmware.get_cluster_hosts import get_cluster_hosts
from vmware.get_vm_network_name import get_vm_network_name
from vmware.add_portgroup import add_portgroup
import atexit

def config_vcenter_portgroups(config, vcenter_password):
    # creates new portgroups within vCenter, returns dict with vm network info
    vc_config = {}

    try:
        # Login to vCenter, skips SSL verification
        serviceInstance = SmartConnectNoSSL(host=config['vcenter_ip'],
                                            user=config['vcenter_username'],
                                            pwd=vcenter_password,
                                            port=443)
        atexit.register(Disconnect, serviceInstance)
        content = serviceInstance.RetrieveContent()
    except IOError:
        print("*** vCenter Login Error ***")
        exit()

    # get host list for the HX cluster we want to add the new VLAN to
    hosts = get_cluster_hosts(content,
                              config['vcenter_datacenter_name'],
                              config['vcenter_cluster_name'])

    # get network type (vswitch/DVS) and vm network name from vCenter
    vc_config['vm_network'] = get_vm_network_name(hosts, config['ucs_mac'])

    for new_vlan in config['vlans']:
        # add portgroup(s) to vswitch or DVS
        # this assume the first valid entry is correct for all vswitch/DVS names
        add_portgroup(content, hosts, vc_config['vm_network'], new_vlan['name'], new_vlan['vlan_id'])
    return vc_config
