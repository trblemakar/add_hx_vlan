__author__ = 'jamakar'

from vmware.login_vcenter import login_vcenter
from vmware.get_cluster_hosts import get_cluster_hosts
from vmware.get_vm_network_name import get_vm_network_name
from vmware.add_portgroup import add_portgroup

def config_vcenter_portgroups(config, password):
    # creates new portgroups within vCenter, returns dict with vm network info

    content = login_vcenter(config, password)

    # get host list for the HX cluster we want to add the new VLAN to
    hosts = get_cluster_hosts(content,
                              config['vcenter_datacenter_name'],
                              config['vcenter_cluster_name'])

    # create temp config dict
    vc_config = {}

    # get network type (vswitch/DVS) and vm network name from vCenter
    vc_config['vm_network'] = get_vm_network_name(hosts, config['ucs_mac'])

    for new_vlan in config['vlans']:
        # add portgroup(s) to vswitch or DVS
        # this assume the first valid entry is correct for all vswitch/DVS names
        add_portgroup(content, hosts, vc_config['vm_network'], new_vlan['name'], new_vlan['vlan_id'])

    return vc_config
