__author__ = 'jamakar'

def get_cluster_obj(content, vimtype, name):
     # get the vsphere object associated with a given text name

    obj = None
    container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
    for c in container.view:
        if c.name == name:
            obj = c
            break
    return obj
