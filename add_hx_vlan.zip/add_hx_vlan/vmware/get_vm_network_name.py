__author__ = 'jamakar'

def get_mac_to_vmnic(hosts, ucs_mac):
    # looks for VM network assigned to ucs_mac, could be vswitch or dvs. returns vmnic name and host

    found = {}

    # iterate through each host, build a mac to vmnic mapping
    for host in hosts:
        pnics = host.config.network.pnic
        # look for vmnic with the ucs_mac address
        for pnic in pnics:
            if pnic.mac == ucs_mac:
                found['host'] = host
                found['vmnic'] = pnic.device
                return found


def get_vm_network_name(hosts, ucs_mac):
    # looks for VM network assigned to ucs_mac, could be vswitch or dvs.
    # returns dict with is_dvs: True/False and network_name

    print("Gathering vCenter Networking Information...")

    found = get_mac_to_vmnic(hosts, ucs_mac)

    vm_network = {}
    vm_network['is_dvs'] = False
    host = found['host']

    # check for dvs, if a dvs is found do this
    if host.config.network.proxySwitch:
        for dswitch in host.config.network.proxySwitch:
            pnics = dswitch.spec.backing.pnicSpec
            for pnic in pnics:
                if pnic.pnicDevice == found['vmnic']:
                    vm_network['is_dvs'] = True
                    vm_network['network_name'] = dswitch.dvsName
                    return vm_network

    # if not a dvs, iterate through each host vswitch
    for vswitch in host.config.network.vswitch:
        pnics = vswitch.spec.bridge.nicDevice
        for pnic in pnics:
            if pnic == found['vmnic']:
                vm_network['network_name'] = vswitch.name
                return vm_network
