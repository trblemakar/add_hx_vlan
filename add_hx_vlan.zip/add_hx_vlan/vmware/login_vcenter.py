__author__ = 'jamakar'

from pyVim.connect import SmartConnectNoSSL, Disconnect
import atexit

def login_vcenter(config, password):
    # login to vCenter

    try:
        # Login to vCenter, skips SSL verification
        serviceInstance = SmartConnectNoSSL(host=config['vcenter_ip'],
                                            user=config['vcenter_username'],
                                            pwd=password,
                                            port=443)
        atexit.register(Disconnect, serviceInstance)
        content = serviceInstance.RetrieveContent()
        return content
    except IOError:
        print("*** vCenter Login Error ***")
        exit()
