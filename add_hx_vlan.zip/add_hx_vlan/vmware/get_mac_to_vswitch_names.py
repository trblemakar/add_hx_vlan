from __future__ import print_function

__author__ = 'jamakar'

def get_mac_to_vswitch_names(hosts):
    # returns dict with per host mac to vswitch name mappings

    mac_to_vswitch_names = {}
    # iterate through each host
    for host in hosts:
        host_pnics = {}
        pnics = host.config.network.pnic
        # get each host pnic and mac address
        for pnic in pnics:
            host_pnics[pnic.device] = pnic.mac

        host_vswitch_names = {}
        vswitches = host.config.network.vswitch
        # iterate through each host vswitch
        for vswitch in vswitches:
            vswitch_vmnics = vswitch.spec.bridge.nicDevice
            # get each vswitch name that maps to the pnic mac address
            for vswitch_vmnic in vswitch_vmnics:
                host_vswitch_names[host_pnics[vswitch_vmnic]] = vswitch.name

        # add mac to vswitch name mapping per host
        mac_to_vswitch_names[host.name] = host_vswitch_names
    return mac_to_vswitch_names