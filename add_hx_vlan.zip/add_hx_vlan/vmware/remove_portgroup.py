__author__ = 'jamakar'

from vmware.remove_dvs_portgroup import remove_dvs_portgroup
from vmware.get_cluster_hosts import get_cluster_hosts
from vmware.remove_vswitch_portgroup import remove_vswitch_portgroup

def remove_portgroup(content, config):
    # remove portgroup(s) for vswitch or DVS

    if config['vm_network']['is_dvs']:
        for vlan in config['vlans']:
            remove_dvs_portgroup(content, config['vm_network']['network_name'], vlan['name'])
    else:
        # get host list for the HX cluster we want to remove the VLAN from
        hosts = get_cluster_hosts(content,
                                  config['vcenter_datacenter_name'],
                                  config['vcenter_cluster_name'])
        for host in hosts:
            for vlan in config['vlans']:
                remove_vswitch_portgroup(host, vlan['name'])
