__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9.8
from ucsmsdk.mometa.fabric.FabricVlan import FabricVlan

def create_ucs_vlan(handle, new_vlan):
    # create new Global UCS VLAN

    # handle (UcsHandle)
    # sharing (String) : ["community", "isolated", "none", "primary"]
    # vlan_name (String) : VLAN Name
    # vlan_id (String): VLAN ID
    # mcast_policy_name (String) : Multicast Policy Name
    # compression_type (string) : ["excluded", "included"]
    # default_net (String) : ["false", "no", "true", "yes"]
    # pub_nw_name (String) :
    # vlan_dn (String) :

    obj = handle.query_dn(new_vlan['vlan_dn'])

    if not obj:
        raise ValueError("LAN {} is not available" .format(new_vlan['vlan_dn']))

    mo = FabricVlan(parent_mo_or_dn=obj,
                    sharing=new_vlan['sharing'],
                    name=new_vlan['name'],
                    id=new_vlan['vlan_id'],
                    mcast_policy_name=new_vlan['mcast_policy_name'],
                    policy_owner=new_vlan['policy_owner'],
                    default_net=new_vlan['default_net'],
                    pub_nw_name=new_vlan['pub_nw_name'],
                    compression_type=new_vlan['compression_type'])

    handle.add_mo(mo, modify_present=False)
    handle.commit()

    print("UCSM: Created Global VLAN: {}({}) in {}" .format(new_vlan['name'],
                                                            new_vlan['vlan_id'],
                                                            new_vlan['vlan_dn']))
