__author__ = 'jamakar'

from UCS.ucsm_version_check import ucsm_version_check
from UCS.build_ucs_vlans import build_ucs_vlans
from UCS.create_ucs_vlan import create_ucs_vlan
from UCS.add_vlan_to_vnic_temp import add_vlan_to_vnic_temp
from UCS.get_sp_vnic_mac import get_sp_vnic_mac
from ucsmsdk.ucshandle import UcsHandle

def config_ucs_vlans(config, ucsm_password):
    # creates new UCS VLANs, adds them to vNIC temp, finds MAC address for vNIC adapter, returns dict
    ucs_config = {}

    # build list of VLAN dict for new VLAN(s) within UCSM
    ucs_config['vlans'] = build_ucs_vlans(config['vlan_name'], config['vlan_ids'])

    # set UCSM parent dn
    parent_dn = "org-root/org-" + config['ucsm_org']

    try:
        # Open UCSM session
        ucsm_handle = UcsHandle(config['ucsm_vip'], config['ucsm_username'], ucsm_password)
        ucsm_handle.login()
    except IOError:
        print("*** UCS Login Error ***")
        exit()

    # do UCSM version check 3.2 or above
    ucsm_version_check(ucsm_handle)

    # create new VLAN(s) within UCSM
    for new_vlan in ucs_config['vlans']:
        # create new VLAN within UCSM
        create_ucs_vlan(ucsm_handle, new_vlan)
        # add new VLAN(s) to vm-network-a vNIC template within UCSM, only primary vNIC required
        add_vlan_to_vnic_temp(ucsm_handle, parent_dn, new_vlan, config['vnic_name'])

    # get mac address from UCSM assigned to vm-network-a vNIC, used in vCenter to find vswitch name
    ucs_config['ucs_mac'] = get_sp_vnic_mac(ucsm_handle, parent_dn, config['vnic_name'])

    # close UCSM session
    ucsm_handle.logout()

    # return ucs_config dict
    return ucs_config
