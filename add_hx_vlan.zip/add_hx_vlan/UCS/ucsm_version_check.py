__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9.8

def ucsm_version_check(handle):

    ucsm = handle.version
    ucsm_version = ucsm.version

    if ucsm_version[0] == "3" and (ucsm_version[2] == "1" or ucsm_version[2] == "2"):
        print("Running UCSM version: {}".format(ucsm_version))
    elif ucsm_version[0] == "4" and ucsm_version[2] == "0":
        print("Running UCSM version: {}".format(ucsm_version))
    else:
        print("*** {} is an unsupported version ***".format(ucsm_version))
        exit()
