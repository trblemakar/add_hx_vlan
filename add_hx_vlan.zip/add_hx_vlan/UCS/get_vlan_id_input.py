__author__ = 'jamakar'

def is_int(vlan_id):
    # makes sure VLAN ID is an integer
    try:
        id = int(vlan_id)
        return True
    except:
        return False


def in_range(vlan_id):
    # makes sure VLAN ID is within the proper range
    return int(vlan_id) > 0 and int(vlan_id) < 4093


def valid(vlan_id):
    # makes sure the VLAN ID is not in the invalid range
    return int(vlan_id) not in range(4030, 4049)


def get_vlan_id_input():
    # single VLAN ID input
    while True:
        try:
            vlan_id = input("Enter new VLAN ID: ")
            assert is_int(vlan_id)
            assert in_range(vlan_id)
            assert valid(vlan_id)
            return list(vlan_id)
        except AssertionError:
            print("*** Invalid VLAN ID. Please try again! ***")
            print("Valid range is 2-4029, 4050-4092.")


def ids_in_range(vlan_ids):
    # makes sure VLAN IDs is within the proper range
    for vlan_id in vlan_ids:
        if vlan_id <= 0 or vlan_id >= 4093:
            return False
    return True


def ids_valid(vlan_ids):
    # makes sure the VLAN IDs is not in the invalid range
    for vlan_id in vlan_ids:
        if vlan_id in range(4030, 4049):
            return False
    return True


def get_vlan_ids_input():
    # single or multiple VLAN ID input
    # takes user input and builds a list of VLAN IDs, returns a list of VLAN IDs
    while True:
        try:
            input = input("Enter new VLAN ID: ")

            # remove whitespace space
            no_spaces = input.replace(" ", "")
            # look for ,
            no_comma = no_spaces.split(",")

            range_list = []
            vlan_list = []
            for id in no_comma:
                if "-" in id:
                    range_list.append(id)
                else:
                    assert is_int(id)
                    vlan_list.append(int(id))

            for r in range_list:
                temp = r.split("-")
                assert is_int(temp[0])
                assert is_int(temp[1])
                vlan_list.extend(range(int(temp[0]), int(temp[1])+1))

            # remove duplicates
            vlan_list = list(dict.fromkeys(vlan_list))
            # sort from low to high
            vlan_list.sort()

            # check VLAN ID
            assert ids_in_range(vlan_list)
            assert ids_valid(vlan_list)

            # convert to string
            vlan_list = list(map(str, vlan_list))
            return vlan_list
        except AssertionError:
            print("*** Invalid VLAN ID. Please try again! ***")
            print("Valid range is 2-4029, 4050-4092.")
