__author__ = 'jamakar'

def is_int(vlan_id):
    # makes sure VLAN ID is an integer
    try:
        id = int(vlan_id)
        return True
    except:
        return False


def in_range(vlan_id):
    # makes sure VLAN ID is within the proper range
    return int(vlan_id) > 0 and int(vlan_id) < 4093


def valid(vlan_id):
    # makes sure the VLAN ID is not in the invalid range
    return int(vlan_id) not in range(4030, 4049)


def get_vlan_id_input():
    while True:
        try:
            vlan_id = raw_input("Enter new VLAN ID: ")
            assert is_int(vlan_id)
            assert in_range(vlan_id)
            assert valid(vlan_id)
            return vlan_id
        except AssertionError:
            print("*** Invalid VLAN ID. Please try again! ***")
            print("Valid range is 2-4029, 4050-4092.")