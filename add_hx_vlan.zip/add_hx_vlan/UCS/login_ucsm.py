__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9.8
from ucsmsdk.ucshandle import UcsHandle

def login_ucsm(config, password):
    # login to UCSM, return handle
    try:
        # Open UCSM session
        ucsm_handle = UcsHandle(config['ucsm_vip'], config['ucsm_username'], password)
        ucsm_handle.login()
        return ucsm_handle
    except IOError:
        print("*** UCS Login Error ***")
        exit()
