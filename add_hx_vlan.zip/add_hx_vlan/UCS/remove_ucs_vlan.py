__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9.8

def remove_ucs_vlan(handle, vlan):
    # delete UCS VLAN

    query_dn = vlan['vlan_dn'] + "/net-" + vlan['name']
    obj = handle.query_dn(query_dn)

    handle.remove_mo(obj)
    handle.commit()

    print("UCSM: Removed Global VLAN: {}({}) in {}" .format(vlan['name'],
                                                            vlan['vlan_id'],
                                                            vlan['vlan_dn']))
