__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def get_sp_vnic_macs(handle, parent_dn, vnic_name):
    # return vnic mac addresses that maps to a vnic name under parent_dn org

    class_id = "AdaptorHostEthIf"
    macs = []
    adapters = handle.query_classid(class_id)
    for adapter in adapters:
        if (adapter.name == vnic_name) and (adapter.vnic_dn.startswith(parent_dn)):
            macs.append(adapter.mac.lower())
    return macs