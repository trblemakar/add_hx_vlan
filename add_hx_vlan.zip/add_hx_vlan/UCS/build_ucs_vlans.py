__author__ = 'jamakar'

def build_ucs_vlans(vlan_name, vlan_ids):
    # build a list of VLAN dict, returns list

    vlan_list = []

    if len(vlan_ids) == 1:
        vlan_list.append({
            "name": vlan_name,
            "sharing": "none",
            "vlan_id": str(vlan_ids[0]),
            "mcast_policy_name": "",
            "policy_owner": "local",
            "compression_type": "included",
            "default_net": "no",
            "pub_nw_name": "",
            "vlan_dn": "fabric/lan"
        })
        return vlan_list

    for id in vlan_ids:
        if len(vlan_name) == 32:
            name = vlan_name[0:(31-len(id))] + "_" + str(id)
        else:
            name = vlan_name + "_" + str(id)
        vlan_list.append({
            "name": name,
            "sharing": "none",
            "vlan_id": str(id),
            "mcast_policy_name": "",
            "policy_owner": "local",
            "compression_type": "included",
            "default_net": "no",
            "pub_nw_name": "",
            "vlan_dn": "fabric/lan"
        })
    return vlan_list
