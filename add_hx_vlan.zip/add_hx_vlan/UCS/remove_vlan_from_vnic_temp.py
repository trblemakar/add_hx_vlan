__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9.8
from ucsmsdk.mometa.vnic.VnicLanConnTempl import VnicLanConnTempl

def remove_vlan_from_vnic_temp(handle, parent_dn, vlan, vnic_temp):
    # remove VLAN from vNIC template

    mo = VnicLanConnTempl(parent_mo_or_dn=parent_dn, name=vnic_temp)

    query_dn = parent_dn + "/lan-conn-templ-" + vnic_temp + "/if-" + vlan['name']

    mo_1 = handle.query_dn(query_dn)

    handle.remove_mo(mo_1)
    handle.add_mo(mo, True)
    handle.commit()

    print("UCSM: Removed VLAN: {}({}) from {} vNIC template in Org: {}".format(vlan['name'],
                                                                               vlan['vlan_id'],
                                                                               vnic_temp,
                                                                               parent_dn.replace("org-root/org-", "")))
