__author__ = 'jamakar'

def is_length(vlan_name):
    # makes sure VLAN name is not greater the 32 characters
    return len(vlan_name) > 0 and len(vlan_name) <= 32


def validate_chars(vlan_name):
    # checks VLAN name for invalid characters
    invalid_characters = [' ', '~', '!', '@', '#', '$', '%', '^', '&', '*', '[', ']',
                          '(', ')', '+', '=', '/', '?', '<', '>', ';', '{', '}', '|']
    is_found = True
    for char in invalid_characters:
        if char in vlan_name:
            is_found = False
    return is_found


def get_vlan_name_input():
    # checks VLAN name length and characters, returns VLAN name
    while True:
        try:
            vlan_name = input("Enter new VLAN name: ")
            assert is_length(vlan_name)
            assert validate_chars(vlan_name)
            return vlan_name
        except AssertionError:
            print("*** Invalid VLAN name. Please try again! ***")
            print("Maximum length 32 characters, cannot include: ~!@#$%^&*()+= ")