__author__ = 'jamakar'

def is_length(vlan_name):
    # makes sure VLAN name is not greater the 32 characters
    return len(vlan_name) <= 32


def get_vlan_name_input():
    # checks VLAN name length
    while True:
        try:
            vlan_name = raw_input("Enter new VLAN name: ")
            assert is_length(vlan_name)
            return vlan_name
        except AssertionError:
            print("*** Invalid VLAN name. Please try again! ***")
            print("Maximum length 32 characters, cannot include: ~!@#$%^&*()+= ")