__author__ = 'jamakar'

from UCS.login_ucsm import login_ucsm
from UCS.ucsm_version_check import ucsm_version_check
from UCS.remove_vlan_from_vnic_temp import remove_vlan_from_vnic_temp
from UCS.remove_ucs_vlan import remove_ucs_vlan

def remove_ucs_vlans(config, password):
    # login to UCSM
    ucsm_handle = login_ucsm(config, password)

    # do UCSM version check 3.2 or above
    ucsm_version_check(ucsm_handle)

    # set UCSM parent dn
    parent_dn = "org-root/org-" + config['ucsm_org']

    for vlan in config['vlans']:
        # first, remove VLAN from vNIC template
        remove_vlan_from_vnic_temp(ucsm_handle, parent_dn, vlan, config['vnic_name'])
        # second, delete VLAN from UCSM
        remove_ucs_vlan(ucsm_handle, vlan)

    # close UCSM session
    ucsm_handle.logout()
