__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def add_vlan_to_vnic_temp(handle, parent_dn, new_vlan, vnic_temp):

    from ucsmsdk.mometa.vnic.VnicLanConnTempl import VnicLanConnTempl
    from ucsmsdk.mometa.vnic.VnicEtherIf import VnicEtherIf

    mo = VnicLanConnTempl(parent_mo_or_dn=parent_dn,
                          name=vnic_temp)

    mo_1 = VnicEtherIf(parent_mo_or_dn=mo,
                       default_net="no",
                       name=new_vlan['name'])

    handle.add_mo(mo, True)
    handle.commit()

    print("Added VLAN: {}({}) to {} UCSM vNIC template in Org: {}" .format(new_vlan['name'],
                                                                           new_vlan['vlan_id'],
                                                                           vnic_temp,
                                                                           parent_dn.replace("org-root/org-", "")))
